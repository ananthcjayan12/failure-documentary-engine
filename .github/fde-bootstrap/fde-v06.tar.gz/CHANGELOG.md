# Changelog

## 0.6.0

- Reordered production around an authoritative narration layer before visual planning.
- Added chapter-cached Gemini TTS, ElevenLabs timed TTS, manual narration and offline mock adapters.
- Added chapter audio quality gates, narration manifests, provider-native alignment and optional local Whisper word timing.
- Expanded the AI Orchestrator to 24 capability-routed tasks across Story, Narration, Visuals, Sound and Assembly.
- Added Anthropic Messages API structured output support with retries and strict schema validation.
- Added persistent job IDs, append-only structured events, raw logs, Server-Sent Events, restart reconciliation, pause-after-current, immediate stop and resume.
- Reworked image and video generation as resumable per-asset queues that import every successful asset immediately.
- Integrated the AI Sound Effects Library with semantic Director intentions, deterministic candidate resolution, valid-ID enforcement and FFmpeg narration-priority mixing.
- Added a dedicated Audio workspace, phase-based model map, capability-specific route settings and 12 visible production stages.
- Added synchronized narration/SFX muxing to both FFmpeg and HyperFrames render paths.
- Added automated tests for narration cache reuse, timing, sound selection, mixing, structured events and pause/resume behavior.

## 0.5.0

- Added native Grok Build CLI support for structured reasoning, image generation and image-to-video generation.
- Added streaming-JSON recovery, media path/URL discovery and preserved raw Grok output.
- Added asset-scoped media generation ledgers, retries, fallbacks and interruption-safe resumability.
- Expanded the AI Orchestrator from 13 to 17 capability-routed tasks.
- Added explicit `structured`, `image`, `video`, `audio` and `render` capabilities.
- Added capability-filtered provider selection and compatibility validation.
- Added the Grok First and Subscription UI profiles.
- Added a Custom CLI Adapter with separate structured and media command templates.
- Added a provider-agnostic routed structured agent supporting cross-adapter fallback.
- Added HyperFrames 0.7.62 and GSAP 3.13.0 as the deterministic browser-render runtime.
- Added `hf-seek` timeline compositions, linting, resumable entry-aligned render chunks, FFprobe validation, FFmpeg concatenation and narration muxing.
- Added automatic FFmpeg renderer fallback.
- Rebuilt the Production and Provider UI for native media generation and provider capabilities.
- Added automated tests for capability routing, cross-provider fallback, media resumability and HyperFrames contracts.

## 0.4.0

- Added the AI Orchestrator main workspace.
- Added 13 persisted task-to-model routes.
- Added routing profiles, editable prompt packs and provider health checks.
- Added reasoning, temperature, timeout, retry and fallback controls.
- Integrated selected routes into background jobs.
